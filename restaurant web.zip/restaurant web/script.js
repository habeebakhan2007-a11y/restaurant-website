let cart = [];
let total = 0;

function addToCart(item, price) {
  cart.push({ item, price });
  total += price;
  updateCart();
}

function removeFromCart(index) {
  total -= cart[index].price;
  cart.splice(index, 1);
  updateCart();
}

function updateCart() {
  const list = document.getElementById('cartList');
  list.innerHTML = cart
    .map((c, i) => 
      `<li>${c.item} — Rs. ${c.price} 
       <button onclick="removeFromCart(${i})" class="remove-btn">Remove</button></li>`
    )
    .join('');
  document.getElementById('cartTotal').textContent = `Total: Rs. ${total}`;
}

// Handle order confirmation
document.getElementById('orderForm').addEventListener('submit', e => {
  e.preventDefault();
  const msg = document.getElementById('orderMessage');
  if (cart.length === 0) {
    msg.textContent = '❌ Your cart is empty. Please add items first.';
    msg.style.color = 'red';
  } else {
    msg.textContent = '✅ Thank you! Your order has been sent to Taste Haven.';
    msg.style.color = 'green';
    cart = [];
    total = 0;
    updateCart();
    e.target.reset();
  }
});

// Handle booking confirmation
document.getElementById('bookingForm').addEventListener('submit', e => {
  e.preventDefault();
  const msg = document.getElementById('bookingMessage');
  msg.textContent = '✅ Your table has been booked successfully!';
  msg.style.color = 'green';
  e.target.reset();
});
